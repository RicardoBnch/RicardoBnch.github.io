// Para ver esta mensagem é necessário pressionar F12 no 
// navegador.
console.log("Alo Ha!")